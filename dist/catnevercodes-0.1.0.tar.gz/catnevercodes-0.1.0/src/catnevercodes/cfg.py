config = {
    "dingtalk": {
        "webhook": "",
        "mobiles": [""]
    },
}